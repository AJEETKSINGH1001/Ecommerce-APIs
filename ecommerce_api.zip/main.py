from fastapi import FastAPI, Depends, HTTPException, status
from pydantic import BaseModel, EmailStr, Field
from typing import List

app = FastAPI(
    title="E-Commerce API",
    description="""
This is the backend API for an E-Commerce platform.  
It supports **user authentication**, **product management**, **shopping cart**, **checkout**, and **order tracking**.

## **Authentication**
- Sign up with a valid email and password.
- Log in to receive a JWT token.
- Use the token in Swagger UI by clicking **Authorize** and entering `Bearer <your_token>`.

## **Products**
- Add, update, delete, and list products.
- Only **admins** can add or modify products.

## **Orders**
- Add products to the cart.
- Checkout to create an order.
- View order list and generate invoices.

""",
    version="1.0.0",
    contact={
        "name": "Your Name",
        "email": "you@example.com",
    }
)

class UserCreate(BaseModel):
    email: EmailStr = Field(..., example="user@example.com")
    password: str = Field(..., min_length=6, example="securepassword")

class UserLogin(BaseModel):
    email: EmailStr = Field(..., example="user@example.com")
    password: str = Field(..., example="securepassword")

class ProductCreate(BaseModel):
    name: str = Field(..., example="Laptop")
    price: float = Field(..., example=999.99)
    stock: int = Field(..., example=10)

class ProductResponse(ProductCreate):
    id: int = Field(..., example=1)

class CartItem(BaseModel):
    product_id: int = Field(..., example=1)
    quantity: int = Field(..., example=2)

class OrderItemResponse(BaseModel):
    product_name: str = Field(..., example="Laptop")
    quantity: int = Field(..., example=2)
    price: float = Field(..., example=999.99)


@app.post("/signup", tags=["Authentication"], summary="Create a new user account",
          response_description="User created successfully")
def signup(user: UserCreate):
    return {"message": "User created successfully", "user_id": 1}

@app.post("/login", tags=["Authentication"], summary="Authenticate user & get JWT token")
def login(user: UserLogin):
    return {"access_token": "JWT_TOKEN_HERE", "token_type": "bearer"}

@app.post("/products", tags=["Products"], summary="Add a new product", response_model=ProductResponse)
def add_product(product: ProductCreate):
    return ProductResponse(id=1, **product.dict())

@app.get("/products", tags=["Products"], summary="List all products", response_model=List[ProductResponse])
def list_products():
    return [
        ProductResponse(id=1, name="Laptop", price=999.99, stock=10),
        ProductResponse(id=2, name="Smartphone", price=499.99, stock=20)
    ]

@app.post("/cart", tags=["Cart"], summary="Add product to cart")
def add_to_cart(item: CartItem):
    return {"message": f"Added {item.quantity} of product {item.product_id} to cart"}

@app.post("/checkout", tags=["Orders"], summary="Checkout and create order")
def checkout():
    return {
        "order_id": 1,
        "total": 1999.98,
        "status": "confirmed"
    }

@app.get("/orders", tags=["Orders"], summary="Get user's orders", response_model=List[OrderItemResponse])
def get_orders():
    return [
        OrderItemResponse(product_name="Laptop", quantity=2, price=999.99)
    ]

@app.get("/orders/{order_id}/invoice", tags=["Orders"], summary="Generate invoice for an order")
def get_invoice(order_id: int):
    return {"invoice_url": f"http://127.0.0.1:8000/invoices/{order_id}.pdf"}
